<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Userimages extends Model
{
    //
}
