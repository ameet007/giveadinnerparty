<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class charity_transaction_reports extends Model
{
    //
}
