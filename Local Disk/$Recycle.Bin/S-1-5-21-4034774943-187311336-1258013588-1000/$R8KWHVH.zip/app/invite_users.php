<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invite_users extends Model
{
    //
}
