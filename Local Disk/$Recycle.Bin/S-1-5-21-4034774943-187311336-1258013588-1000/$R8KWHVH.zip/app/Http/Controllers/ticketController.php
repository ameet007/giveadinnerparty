<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\events;
use App\Charity;
use App\tickets;
use DB;

class ticketController extends Controller
{
    public function ticket_listing(Request $request, $args='all')
	{	
		//echo $args;
		//$tickets = tickets::get();
		if($args!='all')
		{	
			$where = "where tickets.status='$args'";
		}
		else
		{
			$where ="";
		}
		$tickets = DB::select("select tickets.* ,users.name as user_name ,events.title as event_title from tickets inner join users on tickets.user_id = users.id inner join events on events.id=tickets.event_id $where ");
	
		return view('admin.tickets.listing')->with(['tickets'=>$tickets,]);
	}
	
	public function change_ticket_status(Request $request, $id='0')
	{	
		tickets::where('id',$id)->update(['status'=>$request->input('status'), ]);
		return redirect('admin/tickets/all')->with(['success'=>'Status changed successfully']);
	}
}
