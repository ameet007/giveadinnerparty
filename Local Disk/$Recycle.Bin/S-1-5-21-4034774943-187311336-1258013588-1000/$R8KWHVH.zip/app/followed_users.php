<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class followed_users extends Model
{
    //
}
