<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class contactController extends Controller
{
   /* public function create()
    {
        return view('about.contact');
    }

    public function store()
    {
    }*/
	
	public function
}
