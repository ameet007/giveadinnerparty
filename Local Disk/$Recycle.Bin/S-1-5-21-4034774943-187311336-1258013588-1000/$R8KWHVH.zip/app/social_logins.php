<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class social_logins extends Model
{
    //
}
